package com.GL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class G1BedGradedProject4Application {

	public static void main(String[] args) {
		SpringApplication.run(G1BedGradedProject4Application.class, args);
	}

}
